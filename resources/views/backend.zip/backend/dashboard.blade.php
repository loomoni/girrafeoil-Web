@extends('backend.layouts.base')
@section('content')
    {{-- <h4>Dashboard under construction</h4> --}}
@endsection